
public class Usuario {

    private String login;
    private String Senha;

    public String GetLogin() {
        return login;
    }

    public void SetLogin(String login) {
        this.login = login;
    }

    public String GetSenha() {
        return Senha;
    }

    public void SetSenha(String Senha) {
        this.Senha = Senha;
    }

    public boolean Validar() {
        if (this.GetLogin().equals("aaa") && this.GetSenha().equals("1234")) {
            return true;
        } else {
            return false;
        }
    }

}
