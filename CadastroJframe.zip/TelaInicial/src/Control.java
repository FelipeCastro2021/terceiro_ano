
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Control {

    Usuario u = new Usuario();
    Menu m = new Menu();

    public boolean logar(String login, String senha) {

        u.SetLogin(login);
        u.SetSenha(senha);

        boolean verificar = u.Validar();
        if (verificar == true) {
            JOptionPane.showMessageDialog(null, "Cadastro realizado com Sucesso!");
            m.setVisible(true);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Cadastro Inválido");
            return false;
        }

    }
}
